document.addEventListener("DOMContentLoaded", function() {
    console.log("Titan Cloud AI website is loaded successfully!");
});